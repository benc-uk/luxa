# Cube Combined

One wgpu cube application that runs as a native desktop binary or as WebAssembly in a browser. The
renderer, camera, model, shader, texture and winit event handling are shared between both targets.

## Structure

The target boundary is intentionally small:

| Code                                                   | Shared       | Purpose                                                       |
| ------------------------------------------------------ | ------------ | ------------------------------------------------------------- |
| `src/app.rs`                                           | Yes          | One `ApplicationHandler` and redraw loop                      |
| `src/renderer.rs`                                      | Yes          | Surface, pipeline, buffers, resize and rendering              |
| `src/camera.rs`, `src/models.rs`, `src/wgpu_helper.rs` | Yes          | All supporting GPU code                                       |
| `src/platform/desktop.rs`                              | Desktop only | Blocking GPU start, native window size and logging            |
| `src/platform/web.rs`                                  | Web only     | Async GPU start, canvas sizing, DOM errors and web event loop |

`src/platform/mod.rs` selects one adapter with `cfg(target_arch = "wasm32")`. The renderer also gets
its `Instant` type through that adapter, avoiding conditional code throughout the rendering path.

Cargo dependencies follow the same boundary. Desktop alone gets `pollster` and `env_logger`; WASM
alone gets `wasm-bindgen`, `web-sys`, `web-time` and console diagnostics. The target not being built
does not compile or ship those dependencies.

## Desktop

```sh
make run
```

Use `make build` or `make release` to build without running.

## Web

Install the browser target and wasm-pack once:

```sh
rustup target add wasm32-unknown-unknown
cargo install wasm-pack
```

Then build and serve the current directory:

```sh
make build-web
make serve
```

Open <http://localhost:8000>. Use `make release-web` for an optimised WebAssembly build. The browser
path is WebGPU only and deliberately has no WebGL fallback.

## Validation

```sh
make check
make clippy
make fmt
```

These commands check both targets where applicable. `make clean` removes Cargo and generated
wasm-pack output.
