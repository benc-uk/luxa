/* tslint:disable */
/* eslint-disable */

export function start(): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly start: () => void;
    readonly wasm_bindgen__convert__closures_____invoke__hf4724010e40e6856: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h52df9eee11d2df5d: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hf8d82d11a6338a04: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hcd399b95a750084a: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hbb7122a484c3e313: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hc19a9a068e81f9c7: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hcc4a12eddd18db70: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h24d27e3073de71ca: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h9fb969290aaa2e2b: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h951fe076c8f9ad45: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h3e6407a5e312e890: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h2145a655803c78f6: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hbfead96981073c35: (a: number, b: number) => number;
    readonly wasm_bindgen__convert__closures_____invoke__h1af9cae684531fe0: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
