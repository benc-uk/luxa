/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const start: () => void;
export const wasm_bindgen__convert__closures_____invoke__hf4724010e40e6856: (a: number, b: number, c: any) => [number, number];
export const wasm_bindgen__convert__closures_____invoke__h52df9eee11d2df5d: (a: number, b: number, c: any, d: any) => void;
export const wasm_bindgen__convert__closures_____invoke__hf8d82d11a6338a04: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__hcd399b95a750084a: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__hbb7122a484c3e313: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__hc19a9a068e81f9c7: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__hcc4a12eddd18db70: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__h24d27e3073de71ca: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__h9fb969290aaa2e2b: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__h951fe076c8f9ad45: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__h3e6407a5e312e890: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__h2145a655803c78f6: (a: number, b: number, c: any) => void;
export const wasm_bindgen__convert__closures_____invoke__hbfead96981073c35: (a: number, b: number) => number;
export const wasm_bindgen__convert__closures_____invoke__h1af9cae684531fe0: (a: number, b: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_exn_store: (a: number) => void;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_destroy_closure: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
